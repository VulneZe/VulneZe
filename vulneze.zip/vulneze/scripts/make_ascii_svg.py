#!/usr/bin/env python3
"""Convertit source-prepped.png en portrait ASCII monochrome qui s'écrit tout seul.

Chaque ligne est révélée par un clip qui s'ouvre de gauche à droite (SMIL),
avec un petit curseur bloc sur le bord. Une seule lecture, puis l'image se fige.

Usage : python scripts/make_ascii_svg.py  ->  vulneze-ascii.svg
"""
import html
import cv2
import numpy as np

SRC = "source-prepped.png"
OUT = "vulneze-ascii.svg"

COLS = 100
RAMP = " .`:-=+*cs#%@"          # clair (léger) -> sombre (dense)
FONT = 9.0                     # taille de police (px)
CW = FONT * 0.6                # largeur d'un caractère monospace
LH = FONT * 1.02 * 1.0         # hauteur de ligne
PAD_X, PAD_Y = 22, 54          # marges (la barre de titre occupe le haut)

INK = "#bff3e6"                # un seul ton, teinte menthe très claire
ACCENT = "#2ebfa5"
BG = "#0b1214"
BAR = "#111b1e"
BORDER = "#1c2b2f"


def build_grid():
    img = cv2.imread(SRC, cv2.IMREAD_GRAYSCALE)
    # recadre sur tête + épaules pour exploiter la grille
    h, w = img.shape
    img = img[int(h * 0.08): h, int(w * 0.04): int(w * 0.96)]
    h, w = img.shape
    rows = int(COLS * (h / w) * 0.5)
    small = cv2.resize(img, (COLS, rows), interpolation=cv2.INTER_AREA)
    # gamma < 1 : donne de la matière au visage (peau claire)
    norm = (small.astype(np.float32) / 255.0) ** 0.72
    idx = ((1.0 - norm) * (len(RAMP) - 1)).round().astype(int)
    lines = ["".join(RAMP[i] for i in row).rstrip() for row in idx]
    return lines


def main():
    lines = build_grid()
    n = len(lines)
    W = int(PAD_X * 2 + COLS * CW)
    H = int(PAD_Y + n * LH + 24)

    out = []
    a = out.append
    a(f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}" role="img" aria-label="Portrait ASCII de Baptiste Rouault (vulneze)">')
    a("<defs>")
    for i in range(n):
        a(f'<clipPath id="c{i}"><rect x="{PAD_X}" y="{PAD_Y + i * LH - 1:.2f}" height="{LH + 2:.2f}" width="0">'
          f'<animate attributeName="width" from="0" to="{COLS * CW + 4:.1f}" begin="{0.35 + i * 0.045:.3f}s" dur="0.55s" fill="freeze" calcMode="spline" keySplines="0.3 0 0.2 1" keyTimes="0;1"/></rect></clipPath>')
    a("</defs>")
    a(f'<rect x="0.5" y="0.5" width="{W - 1}" height="{H - 1}" rx="12" fill="{BG}" stroke="{BORDER}"/>')
    a(f'<path d="M0.5 12.5a12 12 0 0 1 12-12h{W - 25}a12 12 0 0 1 12 12V34H0.5z" fill="{BAR}"/>')
    a(f'<line x1="0.5" y1="34" x2="{W - 0.5}" y2="34" stroke="{BORDER}"/>')
    for k, col in enumerate(("#ff5f57", "#febc2e", ACCENT)):
        a(f'<circle cx="{20 + k * 18}" cy="17.5" r="5" fill="{col}"/>')
    a(f'<text x="{W / 2:.0f}" y="21" text-anchor="middle" font-family="ui-monospace,SFMono-Regular,Menlo,Consolas,monospace" font-size="11" fill="#6f8a88">vulneze@github: ~/portrait</text>')

    a(f'<g font-family="ui-monospace,SFMono-Regular,Menlo,Consolas,&quot;DejaVu Sans Mono&quot;,monospace" font-size="{FONT}" fill="{INK}" xml:space="preserve">')
    for i, line in enumerate(lines):
        if not line.strip():
            continue
        y = PAD_Y + i * LH + FONT * 0.82
        a(f'<text clip-path="url(#c{i})" x="{PAD_X}" y="{y:.2f}" textLength="{len(line) * CW:.1f}" lengthAdjust="spacing">{html.escape(line)}</text>')
    a("</g>")

    # curseur bloc qui suit le bord de révélation, puis disparaît
    a(f'<g fill="{ACCENT}">')
    for i, line in enumerate(lines):
        if not line.strip():
            continue
        t0 = 0.35 + i * 0.045
        y = PAD_Y + i * LH
        a(f'<rect x="{PAD_X}" y="{y:.2f}" width="{CW:.1f}" height="{LH:.2f}" opacity="0">'
          f'<animate attributeName="opacity" values="0;1;1;0" keyTimes="0;0.02;0.9;1" begin="{t0:.3f}s" dur="0.55s" fill="freeze"/>'
          f'<animate attributeName="x" from="{PAD_X}" to="{PAD_X + COLS * CW:.1f}" begin="{t0:.3f}s" dur="0.55s" fill="freeze" calcMode="spline" keySplines="0.3 0 0.2 1" keyTimes="0;1"/></rect>')
    a("</g>")
    a("</svg>")

    with open(OUT, "w", encoding="utf-8") as f:
        f.write("\n".join(out))
    print(f"OK -> {OUT} ({W}x{H}, {n} lignes)")


if __name__ == "__main__":
    main()
